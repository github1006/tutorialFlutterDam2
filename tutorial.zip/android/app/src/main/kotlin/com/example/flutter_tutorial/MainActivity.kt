package com.example.flutter_tutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
