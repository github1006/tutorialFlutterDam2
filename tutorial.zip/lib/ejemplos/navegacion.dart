import 'package:flutter/cupertino.dart';

class DeNavegacion extends StatelessWidget{
  const DeNavegacion({super.key});

  @override
  Widget build (BuildContext context){
    return const Column(
      children:[
        Text('soy widgest de navegacion'),
      ],
    );
  }
}