class QueEsFlutter {
    String descripcion;
    String versionActual;
    QueEsFlutter(
        this.descripcion,
        this.versionActual,
        );
}
List<QueEsFlutter> datotes=[
  QueEsFlutter('''
  Es un SDK móvil, hace posible "El escribe una vez y desplegalo donde sea"
  ''', '3.22.1'),
];